// 5
public class Lion extends Feline {
  public void huntInPack() {
    System.out.println("The lion is hunting in a pack.");
  }
}