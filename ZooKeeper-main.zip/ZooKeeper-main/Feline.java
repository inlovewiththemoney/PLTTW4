// 5
public class Feline extends Animal
{
  public void growl(){
    System.out.println("The feline growls.");
  }
}