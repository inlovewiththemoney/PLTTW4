/*
 * Activity 4.9.2
 */
public class Hooved extends Animal
{
  public void forage()
  {
    System.out.println("The hooved animal forages for food.");
  }
}